﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ThemeColorPickerDemo
{
    public partial class frmBase : Form
    {
        public frmBase()
        {
            InitializeComponent();
        }
    }
}
